"""User CRUD operations."""
from sqlalchemy.orm import Session
from app.models.user import User
from app.schemas.user import UserCreate, UserInDB
from app.utils.security import get_password_hash, verify_password
from fastapi import HTTPException, status
import logging

logger = logging.getLogger(__name__)

def get_user_by_email(db: Session, email: str) -> Optional[UserInDB]:
    """Get user by email."""
    return db.query(User).filter(User.email == email).first()

def get_user_by_username(db: Session, username: str) -> Optional[UserInDB]:
    """Get user by username."""
    return db.query(User).filter(User.username == username).first()

def get_user(db: Session, user_id: int) -> Optional[UserInDB]:
    """Get user by ID."""
    return db.query(User).filter(User.id == user_id).first()

def create_user(db: Session, user: UserCreate) -> UserInDB:
    """Create new user."""
    # Check if email already exists
    if get_user_by_email(db, user.email):
        logger.warning(f"Email {user.email} already registered")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )

    # Check if username already exists
    if get_user_by_username(db, user.username):
        logger.warning(f"Username {user.username} already taken")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already taken"
        )

    hashed_password = get_password_hash(user.password)
    db_user = User(
        email=user.email,
        username=user.username,
        hashed_password=hashed_password
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)

    logger.info(f"Created new user with ID {db_user.id}")
    return db_user

def authenticate_user(db: Session, email: str, password: str) -> Optional[UserInDB]:
    """Authenticate user."""
    user = get_user_by_email(db, email)
    if not user:
        logger.warning(f"Login attempt with non-existent email: {email}")
        return None
    if not verify_password(password, user.hashed_password):
        logger.warning(f"Invalid password attempt for email: {email}")
        return None
    return user