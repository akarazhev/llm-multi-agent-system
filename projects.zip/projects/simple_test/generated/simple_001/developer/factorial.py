import logging
from typing import Union

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def factorial(n: int) -> Union[int, float]:
    """
    Calculate the factorial of a non-negative integer n.

    Args:
        n: A non-negative integer for which to compute the factorial

    Returns:
        The factorial of n (n!)

    Raises:
        ValueError: If n is negative
        TypeError: If n is not an integer

    Examples:
        >>> factorial(5)
        120
        >>> factorial(0)
        1
    """
    # Input validation
    if not isinstance(n, int):
        logger.error("Input must be an integer")
        raise TypeError("Input must be an integer")

    if n < 0:
        logger.error("Factorial is not defined for negative numbers")
        raise ValueError("Factorial is not defined for negative numbers")

    # Base case
    if n == 0:
        return 1

    # Recursive case
    result = 1
    for i in range(1, n + 1):
        result *= i

    logger.info(f"Calculated factorial of {n} = {result}")
    return result