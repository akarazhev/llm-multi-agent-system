# Jira Ticket Structure

## **Epic**: Blog Platform CMS
### **Tasks**
| ID  | Title                          | Type     | Priority | Labels          |
|-----|--------------------------------|----------|----------|-----------------|
| FR-1| Post CRUD API                 | Task     | High     | backend, api    |
| FR-2| Rich Text Editor (Frontend)    | Task     | High     | frontend, ui    |
| FR-6| Categories/Tags Management     | Task     | Medium   | backend, db     |

### **Subtasks for FR-1**
- [ ] Design PostgreSQL schema for posts.
- [ ] Implement FastAPI endpoints (GET/POST/DELETE).
- [ ] Write unit tests for CRUD operations.

**Estimation**: 13 story points (3 + 5 + 5).