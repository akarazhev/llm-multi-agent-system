# Jira Ticket Structure Recommendations

## Epic Structure
1. **Epic: E-Commerce Platform (B2C)**
   - **Initiative**: Build scalable e-commerce platform for 10K+ users.
   - **Duration**: 3 months.

### User Story Tickets
| Ticket ID | Title                          | Type       | Priority | Story Points | Assignee          |
|-----------|--------------------------------|------------|----------|--------------|-------------------|
| EP-1      | Product Catalog (US1)           | User Story | P0       | 5            | Backend Team      |
| EP-2      | Product Search (US2)           | User Story | P1       | 3            | Backend Team      |
| EP-3      | Shopping Cart (US3, US4)        | User Story | P0       | 8            | Backend Team      |
| EP-4      | Payment Integration (US5)      | User Story | P0       | 8            | Backend Team      |
| EP-5      | User Authentication (US6)      | User Story | P0       | 5            | Backend Team      |
| EP-6      | Order History (US7)            | User Story | P1       | 5            | Backend Team      |

### Task Breakdown (Example for Product Service)
| Ticket ID | Title                          | Type    | Parent    | Priority | Story Points | Assignee          |
|-----------|--------------------------------|---------|-----------|----------|--------------|-------------------|
| EP-1-1    | Implement Product CRUD API     | Task    | EP-1      | P0       | 3            | Dev A             |
| EP-1-2    | Write unit tests for CRUD      | Task    | EP-1      | P0       | 2            | Dev B             |
| EP-1-3    | Set up Kubernetes deployment   | Task    | EP-1      | P0       | 5            | DevOps Team       |
| EP-1-4    | Generate OpenAPI docs          | Task    | EP-1      | P1       | 2            | Dev C             |

### Labeling Convention
- `epic:ecommerce-platform`
- `feature:product-service`
- `feature:cart-service`
- `feature:payment-service`
- `feature:user-service`
- `type:user-story`, `type:task`, `type:bug`
- `priority:p0`, `priority:p1`, `priority:p2`