# User Authentication REST API with JWT

## Overview
This document provides comprehensive documentation for the User Authentication REST API that implements JWT (JSON Web Token) based authentication. This API allows clients to authenticate users and obtain JWT tokens for subsequent secured requests.

## API Endpoints

### 1. Authentication Endpoint
| Method | Endpoint         | Description                          |
|--------|------------------|--------------------------------------|
| POST   | /api/auth/login  | Authenticate user and get JWT token   |

### 2. Protected Endpoint (Example)
| Method | Endpoint             | Description                          |
|--------|----------------------|--------------------------------------|
| GET    | /api/protected/data  | Access protected data with JWT       |

## Authentication Flow

1. Client sends credentials to `/api/auth/login`
2. Server validates credentials and returns JWT token
3. Client includes JWT in Authorization header for protected endpoints
4. Server validates JWT on each protected request

## Detailed Endpoint Documentation

### POST /api/auth/login

**Request:**
```http
POST /api/auth/login
Content-Type: application/json

{
    "username": "string",
    "password": "string"
}
```

**Response:**
```http
HTTP/1.1 200 OK
Content-Type: application/json

{
    "access_token": "string",
    "token_type": "Bearer",
    "expires_in": 3600
}
```

**Error Responses:**
- `401 Unauthorized`: Invalid credentials
- `400 Bad Request`: Missing username or password

### GET /api/protected/data

**Request:**
```http
GET /api/protected/data
Authorization: Bearer <your_jwt_token>
```

**Response:**
```http
HTTP/1.1 200 OK
Content-Type: application/json

{
    "data": "protected data content"
}
```

**Error Responses:**
- `401 Unauthorized`: Invalid or expired token

## Code Implementation

### app.py
```python
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
from typing import Optional

# Configuration
SECRET_KEY = "your-secret-key-here"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# FastAPI app
app = FastAPI()

# Security components
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/login")

# Mock user database
fake_users_db = {
    "johndoe": {
        "username": "johndoe",
        "hashed_password": pwd_context.hash("secret"),
        "disabled": False,
    }
}

# Models
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

class User(BaseModel):
    username: str
    disabled: bool = False

class UserInDB(User):
    hashed_password: str

# Utility functions
def verify_password(plain_password: str, hashed_password: str):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str):
    return pwd_context.hash(password)

def get_user(db, username: str):
    if username in db:
        user_dict = db[username]
        return UserInDB(**user_dict)

def authenticate_user(db, username: str, password: str):
    user = get_user(db, username)
    if not user:
        return False
    if not verify_password(password, user.hashed_password):
        return False
    return user

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Dependency
async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username)
    except JWTError:
        raise credentials_exception

    user = get_user(fake_users_db, username=token_data.username)
    if user is None:
        raise credentials_exception
    return user

# API Endpoints
@app.post("/api/auth/login", response_model=Token)
async def login_for_access_token(form_data: dict = Depends()):
    user = authenticate_user(fake_users_db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/api/protected/data")
async def read_items(token: str = Depends(oauth2_scheme)):
    return {"data": "This is protected data"}
```

## Configuration and Setup

### Prerequisites
- Python 3.7+
- FastAPI
- PyJWT
- passlib with bcrypt
- uvicorn

### Installation
```bash
pip install fastapi uvicorn python-jose[cryptography] passlib python-multipart
```

### Running the API
```bash
uvicorn app:app --reload
```

### Environment Variables
Create a `.env` file with the following variables:
```env
SECRET_KEY=your-secret-key-here
ACCESS_TOKEN_EXPIRE_MINUTES=30
```

## Usage Examples

### 1. Authentication Example (Python)
```python
import requests

# Login to get token
login_data = {
    "username": "johndoe",
    "password": "secret"
}
response = requests.post("http://localhost:8000/api/auth/login", json=login_data)
token = response.json()["access_token"]

# Use token to access protected endpoint
headers = {"Authorization": f"Bearer {token}"}
response = requests.get("http://localhost:8000/api/protected/data", headers=headers)
print(response.json())
```

### 2. Authentication Example (cURL)
```bash
# Login
curl -X POST "http://localhost:8000/api/auth/login" \
-H "Content-Type: application/json" \
-d '{"username":"johndoe","password":"secret"}'

# Access protected endpoint
curl -X GET "http://localhost:8000/api/protected/data" \
-H "Authorization: Bearer YOUR_TOKEN_HERE"