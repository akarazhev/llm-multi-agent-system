import pytest
import jwt
from datetime import datetime, timedelta
from apigateway.app import generate_token, decode_token, AuthError, app
from unittest.mock import patch

class TestTokenFunctions:
    """Unit tests for token generation and decoding functions"""

    def test_generate_access_token(self):
        """Test generating an access token"""
        token = generate_token(user_id=1, token_type='access')
        payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=[app.config['JWT_ALGORITHM']])
        assert payload['sub'] == '1'
        assert payload['type'] == 'access'
        assert 'exp' in payload
        assert 'iat' in payload

    def test_generate_refresh_token(self):
        """Test generating a refresh token"""
        token = generate_token(user_id=2, token_type='refresh')
        payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=[app.config['JWT_ALGORITHM']])
        assert payload['sub'] == '2'
        assert payload['type'] == 'refresh'

    def test_generate_token_invalid_type(self):
        """Test generating token with invalid type"""
        with pytest.raises(AuthError) as excinfo:
            generate_token(user_id=1, token_type='invalid')
        assert excinfo.value.status_code == 400
        assert excinfo.value.error == "Invalid token type"

    def test_decode_valid_token(self):
        """Test decoding a valid token"""
        token = generate_token(user_id=1)
        payload = decode_token(token)
        assert payload['sub'] == '1'
        assert payload['type'] == 'access'

    def test_decode_expired_token(self):
        """Test decoding an expired token"""
        expired_token = generate_token(
            user_id=1,
            expires_in=timedelta(minutes=-1)
        )
        with pytest.raises(AuthError) as excinfo:
            decode_token(expired_token)
        assert excinfo.value.status_code == 401
        assert excinfo.value.error == "Token has expired"

    def test_decode_invalid_token(self):
        """Test decoding an invalid token"""
        with pytest.raises(AuthError) as excinfo:
            decode_token("invalid.token.here")
        assert excinfo.value.status_code == 401
        assert excinfo.value.error == "Invalid token"

    @patch('apigateway.app.jwt.decode')
    def test_decode_token_calls_jwt_decode(self, mock_decode):
        """Test that decode_token calls jwt.decode with correct parameters"""
        mock_decode.return_value = {'sub': '1', 'type': 'access'}
        decode_token("test.token")
        mock_decode.assert_called_once_with(
            "test.token",
            app.config['SECRET_KEY'],
            algorithms=[app.config['JWT_ALGORITHM']]
        )

class TestAuthError:
    """Unit tests for AuthError exception"""

    def test_auth_error_initialization(self):
        """Test AuthError initialization"""
        error = AuthError("Test error", 400)
        assert error.error == "Test error"
        assert error.status_code == 400
        assert isinstance(error, Exception)

class TestConfiguration:
    """Unit tests for application configuration"""

    def test_default_secret_key(self):
        """Test that default secret key is set when not in environment"""
        assert app.config['SECRET_KEY'] == 'default-secret-key-for-dev'

    def test_jwt_algorithm(self):
        """Test JWT algorithm configuration"""
        assert app.config