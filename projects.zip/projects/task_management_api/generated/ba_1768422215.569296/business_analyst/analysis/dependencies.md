# Dependencies & Risks

## Dependencies
1. **Database**: PostgreSQL must be available for SQLAlchemy.
2. **Authentication**: `python-jose` for JWT.
3. **WebSockets**: FastAPI WebSocket support.

## Risks
| Risk | Mitigation |
|------|------------|
| Low test coverage | Pair with QA to write integration tests. |
| WebSocket scalability | Use Redis pub/sub for high traffic. |
| JWT security | Rotate keys quarterly. |