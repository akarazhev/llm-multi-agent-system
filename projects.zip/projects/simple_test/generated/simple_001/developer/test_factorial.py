import unittest
import logging
from factorial import factorial

# Configure test logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TestFactorial(unittest.TestCase):
    def test_factorial_zero(self):
        """Test that factorial(0) returns 1"""
        self.assertEqual(factorial(0), 1)

    def test_factorial_positive(self):
        """Test factorial with positive integers"""
        self.assertEqual(factorial(1), 1)
        self.assertEqual(factorial(5), 120)
        self.assertEqual(factorial(10), 3628800)

    def test_factorial_negative(self):
        """Test that factorial raises ValueError for negative numbers"""
        with self.assertRaises(ValueError):
            factorial(-1)
        with self.assertRaises(ValueError):
            factorial(-10)

    def test_factorial_non_integer(self):
        """Test that factorial raises TypeError for non-integer inputs"""
        with self.assertRaises(TypeError):
            factorial(3.5)
        with self.assertRaises(TypeError):
            factorial("5")
        with self.assertRaises(TypeError):
            factorial([5])

if __name__ == '__main__':
    unittest.main()