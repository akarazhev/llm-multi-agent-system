task-management-api/
├── app/                      # Main application code
│   ├── __init__.py
│   ├── main.py               # FastAPI app initialization
│   ├── config.py             # Configuration settings
│   ├── database.py           # Database setup and session management
│   ├── schemas/              # Pydantic models
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── task.py
│   │   └── token.py
│   ├── models/               # SQLAlchemy models
│   │   ├── __init__.py
│   │   ├── user.py
│   │   └── task.py
│   ├── crud/                 # CRUD operations
│   │   ├── __init__.py
│   │   ├── user.py
│   │   └── task.py
│   ├── api/                  # API routes
│   │   ├── __init__.py
│   │   ├── v1/
│   │   │   ├── __init__.py
│   │   │   ├── auth.py       # Authentication endpoints
│   │   │   └── tasks.py      # Task endpoints
│   │   └── websockets.py     # WebSocket endpoints
│   ├── utils/                # Utility functions
│   │   ├── __init__.py
│   │   ├── security.py       # Security utilities
│   │   ├── logging.py        # Logging configuration
│   │   └── websockets.py     # WebSocket utilities
│   └── tests/                # Test files
│       ├── __init__.py
│       ├── test_auth.py
│       ├── test_tasks.py
│       └── test_websockets.py
├── migrations/               # Database migrations
├── docker-compose.yml        # Docker compose configuration
├── Dockerfile                # Dockerfile for the API
├── requirements.txt          # Python dependencies
├── requirements-dev.txt      # Development dependencies
├── .env.example              # Environment variables example
├── README.md                 # Project documentation
└── alembic.ini               # Alembic configuration
```

### File: app/main.py