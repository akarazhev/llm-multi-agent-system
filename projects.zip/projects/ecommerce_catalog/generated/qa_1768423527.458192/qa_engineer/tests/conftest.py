import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from backend.app.main import app
from backend.app.db.base import Base
from backend.app.db.session import get_db
from backend.app.config import settings
from backend.app.models import User, Product, Category, Cart, Order, Payment
from backend.app.schemas import UserCreate
import stripe

# Test database URL
TEST_DATABASE_URL = f"postgresql://{settings.DATABASE_USER}:{settings.DATABASE_PASSWORD}@{settings.DATABASE_HOST}:{settings.DATABASE_PORT}/{settings.DATABASE_NAME}_test"

# Create test database engine
engine = create_engine(TEST_DATABASE_URL, pool_pre_ping=True)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create all tables
Base.metadata.create_all(bind=engine)

# Dependency override
def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c

@pytest.fixture(scope="module")
def test_user(client):
    user_data = {
        "email": "test@example.com",
        "password": "testpassword123",
        "full_name": "Test User",
        "is_admin": False
    }
    response = client.post("/auth/register", json=user_data)
    assert response.status_code == 201
    return {"email": user_data["email"], "password": user_data["password"]}

@pytest.fixture(scope="module")
def admin_user(client):
    user_data = {
        "email": "admin@example.com",
        "password": "adminpassword123",
        "full_name": "Admin User",
        "is_admin": True
    }
    response = client.post("/auth/register", json=user_data)
    assert response.status_code == 201
    return {"email": user_data["email"], "password": user_data["password"]}

@pytest.fixture(scope="module")
def auth_token(client, test_user):
    response = client.post("/auth/login", data={
        "username": test_user["email"],
        "password": test_user["password"]
    })
    assert response.status_code == 200
    return response.json()["access_token"]

@pytest.fixture(scope="module")
def admin_token(client, admin_user):
    response = client.post("/auth/login", data={
        "username": admin_user["email"],
        "password": admin_user["password"]
    })
    assert response.status_code == 200
    return response.json()["access_token"]

@pytest.fixture(scope="module")
def test_products(client, admin_token):
    headers = {"Authorization": f"Bearer {admin_token}"}

    # Create categories
    category_response = client.post(
        "/admin/categories",
        headers=headers,
        json={"name": "Electronics"}
    )
    assert category_response.status_code == 201
    category_id = category_response.json()["id"]

    # Create products
    products = []
    for i in range(3):
        product_data = {
            "name": f"Test Product {i}",
            "description": f"Test description {i}",
            "price": float(i * 10 + 9.99),
            "stock": i * 10 + 5,
            "category_id": category_id,
            "tags": [f"tag{i}", f"electronics"],
            "rating": float(i + 3),
            "images": [
                {"url": f"https://example.com/image{i}.jpg", "is_primary": i == 0},
                {"url": f"https://example.com/image{i}_2.jpg", "is_primary": False}
            ],
            "variants": [
                {"size": "M", "color": "Black", "price_adjustment": 0},
                {"size": "L", "color": "White", "price_adjustment": 2.99}
            ]
        }
        response = client.post("/products", headers=headers, json=product_data)
        assert response.status_code == 201
        products.append(response.json())

    return products

@pytest.fixture(autouse=True)
def setup_stripe_mock():
    # Mock Stripe for testing
    stripe.api_key = "test_api_key"
    stripe.default_account = "test_account"