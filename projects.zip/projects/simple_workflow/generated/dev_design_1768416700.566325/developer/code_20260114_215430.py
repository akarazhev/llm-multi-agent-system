# File: apigateway/requirements.txt
flask==2.3.2
flask-limiter==3.3.0
python-jose==3.3.0
gunicorn==20.1.0