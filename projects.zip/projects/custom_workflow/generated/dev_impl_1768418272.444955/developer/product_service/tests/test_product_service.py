"""
Unit tests for the Product Service
"""

import pytest
from fastapi.testclient import TestClient
from app.main import app, products_db
from datetime import datetime

client = TestClient(app)

@pytest.fixture
def reset_db():
    """Reset the in-memory database before each test"""
    products_db.clear()
    products_db.update({
        1: {
            "id": 1,
            "name": "Test Product",
            "description": "Test Description",
            "price": 99.99,
            "stock": 50,
            "category": "Test",
            "created_at": "2023-01-01T00:00:00",
            "updated_at": "2023-01-01T00:00:00"
        }
    })

def test_health_check():
    """Test the health check endpoint"""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_get_products_empty(reset_db):
    """Test getting products when database is empty"""
    products_db.clear()
    response = client.get("/products")
    assert response.status_code == 200
    assert response.json() == []

def test_get_products(reset_db):
    """Test getting all products"""
    response = client.get("/products")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["id"] == 1
    assert data[0]["name"] == "Test Product"

def test_get_product_not_found():
    """Test getting a non-existent product"""
    response = client.get("/products/999")
    assert response.status_code == 404
    assert response.json()["detail"] == "Product not found"

def test_get_product(reset_db):
    """Test getting a specific product"""
    response = client.get("/products/1")
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == 1
    assert data["name"] == "Test Product"
    assert data["price"] == 99.99

def test_create_product_invalid_price():
    """Test creating a product with invalid price"""
    new_product = {
        "name": "Invalid Price Product",
        "description": "Product with invalid price",
        "price": -10,
        "stock": 10,
        "category": "Test"
    }
    response = client.post("/products", json=new_product)
    assert response.status_code == 400
    assert "Price must be positive" in response.json()["detail"]

def test_create_product_invalid_stock():
    """Test creating a product with invalid stock"""
    new_product = {
        "name": "Invalid Stock Product",
        "description": "Product with invalid stock",
        "price": 10,
        "stock": -5,
        "category": "Test"
    }
    response = client.post("/products", json=new_product)
    assert response.status_code == 400
    assert "Stock cannot be negative" in response.json()["detail"]

def test_create_product(reset_db):
    """Test creating a new product"""
    new_product = {
        "name": "New Product",
        "description": "A brand new product",
        "price": 29.99,
        "stock": 100,
        "category": "Electronics"
    }
    response = client.post("/products", json=new_product)
    assert response.status_code == 201
    data = response.json()
    assert data["id"] == 2
    assert data["name"] == "New Product"
    assert data["price"] == 29.99
    assert "created_at" in data
    assert "updated_at" in data

def test_update_product_not_found():
    """Test updating a non-existent product"""
    update_data = {
        "name": "Updated Name",
        "price": 50.00
    }
    response = client.put("/products/999", json=update_data)
    assert response.status_code == 404
    assert response.json()["detail"] == "Product not found"

def test_update_product_invalid_price():
    """Test updating a product with invalid price"""
    update_data = {
        "price": -20
    }
    response = client.put("/products/1", json=update_data)
    assert response.status_code == 400
    assert "Price must be positive" in response.json()["detail"]

def test_update_product_partial(reset_db):
    """Test partial update of a product"""
    update_data = {
        "price": 149.99,
        "stock": 75
    }
    response = client.put("/products/1", json=update_data)
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == 1
    assert data["name"] == "Test Product"  # unchanged
    assert data["price"] == 149.99
    assert data["stock"] == 75
    assert data["updated