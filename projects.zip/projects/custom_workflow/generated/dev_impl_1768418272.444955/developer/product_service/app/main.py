"""
Product Service - Main application module for the e-commerce product catalog
"""

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
from pydantic import BaseModel
import logging
import os
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Product Service",
    description="E-commerce Product Catalog Service",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory database (will be replaced with PostgreSQL in production)
products_db = {
    1: {
        "id": 1,
        "name": "Wireless Headphones",
        "description": "Noise-cancelling wireless headphones with 30hr battery",
        "price": 199.99,
        "stock": 100,
        "category": "Electronics",
        "created_at": "2023-01-15T10:00:00",
        "updated_at": "2023-01-15T10:00:00"
    },
    2: {
        "id": 2,
        "name": "Smart Watch",
        "description": "Fitness tracking smart watch with heart rate monitor",
        "price": 249.99,
        "stock": 75,
        "category": "Electronics",
        "created_at": "2023-02-20T14:30:00",
        "updated_at": "2023-02-20T14:30:00"
    }
}

class ProductBase(BaseModel):
    name: str
    description: str
    price: float
    stock: int
    category: str

class ProductCreate(ProductBase):
    pass

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    stock: Optional[int] = None
    category: Optional[str] = None

class Product(ProductBase):
    id: int
    created_at: str
    updated_at: str

    class Config:
        from_attributes = True

@app.on_event("startup")
async def startup_event():
    """Initialize resources on service startup"""
    logger.info("Product Service starting up...")
    # In production, this would connect to PostgreSQL
    logger.info("Connected to database")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup resources on service shutdown"""
    logger.info("Product Service shutting down...")

@app.get("/health", summary="Health check endpoint", tags=["health"])
async def health_check():
    """Health check endpoint for monitoring"""
    return {"status": "healthy", "service": "product-service", "timestamp": datetime.utcnow().isoformat()}

@app.get("/products", response_model=List[Product], summary="Get all products", tags=["products"])
async def get_products(skip: int = 0, limit: int = 100):
    """Retrieve a paginated list of all products"""
    try:
        return list(products_db.values())[skip:skip+limit]
    except Exception as e:
        logger.error(f"Error retrieving products: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )

@app.get("/products/{product_id}", response_model=Product, summary="Get product by ID", tags=["products"])
async def get_product(product_id: int):
    """Retrieve a specific product by its ID"""
    try:
        if product_id not in products_db:
            logger.warning(f"Product not found: {product_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Product not found"
            )
        return products_db[product_id]
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving product {product_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )

@app.post("/products", response_model=Product, status_code=status.HTTP_201_CREATED, summary="Create new product", tags=["products"])
async def create_product(product: ProductCreate):
    """Create a new product in the catalog"""
    try:
        # Generate new ID (in production, this would be handled by DB)
        new_id = max(products_db.keys()) + 1 if products_db else 1

        # Validate price
        if product.price <= 0:
            raise ValueError("Price must be positive")

        # Validate stock
        if product.stock < 0:
            raise ValueError("Stock cannot be negative")

        # Create product
        db_product = {
            "id": new_id,
            "name": product.name,
            "description": product.description,
            "price": product.price,
            "stock": product.stock,
            "category": product.category,
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }

        products_db[new_id] = db_product
        logger.info(f"Created new product with ID: {new_id}")
        return db_product
    except ValueError as ve:
        logger.warning(f"Validation error: {str(ve)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(ve)
        )
    except Exception as e:
        logger.error(f"Error creating product: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )

@app.put("/products/{product_id}", response_model=Product, summary="Update product", tags=["products"])
async def update_product(product_id: int, product: ProductUpdate):
    """Update an existing product"""
    try:
        if product_id not in products_db:
            logger.warning(f"Product not found for update: {product_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Product not found"
            )

        db_product = products_db[product_id]

        # Validate price if provided
        if product.price is not None and product.price <= 0:
            raise ValueError("Price must be positive")

        # Validate stock if provided
        if product.stock is not None and product.stock < 0:
            raise ValueError("Stock cannot be negative")

        # Update fields
        if product.name is not None:
            db_product["name"] = product.name
        if product.description is not None:
            db_product["description"] = product.description
        if product.price is not None:
            db_product["price"] = product.price
        if product.stock is not None:
            db_product["stock"] = product.stock
        if product.category is not None:
            db_product["category"] = product.category

        db_product["updated_at"] = datetime.utcnow().isoformat()
        logger.info(f"Updated product with ID: {product_id}")
        return db_product
    except ValueError as ve:
        logger.warning(f"Validation error: {str(ve)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(ve)
        )
    except Exception as e:
        logger.error(f"Error updating product {product_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )

@app.delete("/products/{product_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete product", tags=["products"])
async def delete_product(product_id: int):
    """Delete a product from the catalog"""
    try:
        if product_id not in products_db:
            logger.warning(f"Product not found for deletion: {product_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Product not found"
            )

        del products_db[product_id]
        logger.info(f"Deleted product with ID: {product_id}")
        return None
    except Exception as e:
        logger.error(f"Error deleting product {product_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )