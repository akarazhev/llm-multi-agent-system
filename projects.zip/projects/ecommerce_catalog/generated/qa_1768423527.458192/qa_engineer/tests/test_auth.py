import pytest
from backend.app.utils.security import get_password_hash, verify_password

def test_password_hashing():
    """Test password hashing and verification"""
    password = "testpassword123"
    hashed = get_password_hash(password)

    # Verify the hashed password
    assert verify_password(password, hashed) is True

    # Verify wrong password
    assert verify_password("wrongpassword", hashed) is False

    # Verify different passwords
    assert verify_password("anotherpassword", hashed) is False

def test_user_registration(client):
    """Test user registration endpoint"""
    user_data = {
        "email": "newuser@example.com",
        "password": "securepassword123",
        "full_name": "New User",
        "is_admin": False
    }

    response = client.post("/auth/register", json=user_data)

    assert response.status_code == 201
    data = response.json()
    assert "id" in data
    assert data["email"] == user_data["email"]
    assert data["full_name"] == user_data["full_name"]
    assert "password" not in data  # Password should not be returned

def test_user_login(client, test_user):
    """Test user login endpoint"""
    login_data = {
        "username": test_user["email"],
        "password": test_user["password"]
    }

    response = client.post("/auth/login", data=login_data)

    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert "refresh_token" in data
    assert data["token_type"] == "bearer"

def test_get_current_user(client, auth_token):
    """Test getting current user information"""
    headers = {"Authorization": f"Bearer {auth_token}"}

    response = client.get("/auth/me", headers=headers)

    assert response.status_code == 200
    data = response.json()
    assert data["email"] == "test@example.com"
    assert data["full_name"] == "Test User"

def test_unauthorized_access(client):
    """Test access without authentication"""
    response = client.get("/auth/me")

    assert response.status_code == 401
    assert "detail" in response.json()

def test_invalid_credentials(client):
    """Test login with invalid credentials"""
    login_data = {
        "username": "test@example.com",
        "password": "wrongpassword"
    }

    response = client.post("/auth/login", data=login_data)

    assert response.status_code == 400
    assert "detail" in response.json()