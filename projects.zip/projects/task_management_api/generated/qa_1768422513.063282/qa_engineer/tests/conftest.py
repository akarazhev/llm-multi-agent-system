"""Pytest configuration and fixtures."""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.main import app
from app.database import Base, get_db
from app.config import settings
from app.crud.user import create_user
from app.schemas.user import UserCreate

# Test database setup
SQLALCHEMY_DATABASE_URL = "postgresql://postgres:postgres@localhost:5432/test_taskdb"
engine = create_engine(SQLALCHEMY_DATABASE_URL)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture(scope="module")
def test_db():
    """Create test database and tables."""
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture(scope="function")
def db_session(test_db):
    """Create a new database session for each test."""
    connection = engine.connect()
    transaction = connection.begin()
    session = TestingSessionLocal(bind=connection)

    yield session

    session.close()
    transaction.rollback()
    connection.close()

@pytest.fixture(scope="function")
def client(db_session):
    """Create test client with dependency override."""
    def override_get_db():
        try:
            yield db_session
        finally:
            db_session.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c

@pytest.fixture(scope="module")
def test_user():
    """Create a test user."""
    return UserCreate(
        email="test@example.com",
        username="testuser",
        password="testpassword123"
    )

@pytest.fixture(scope="function")
def registered_user(db_session, test_user):
    """Register a test user in the database."""
    return create_user(db_session, test_user)

@pytest.fixture(scope="function")
def auth_token(client, registered_user):
    """Get authentication token for the test user."""
    login_data = {
        "username": registered_user.email,
        "password": "testpassword123"
    }
    response = client.post("/auth/login", data=login_data)
    return response.json()["access_token"]

@pytest.fixture(scope="function")
def authenticated_client(client, auth_token):
    """Create authenticated client with token."""
    client.headers = {
        "Authorization": f"Bearer {auth_token}"
    }
    return client