# Product Service API Reference

## Overview

This document provides detailed information about the Product Service REST API, including endpoints, request/response formats, and authentication requirements.

## Base URL