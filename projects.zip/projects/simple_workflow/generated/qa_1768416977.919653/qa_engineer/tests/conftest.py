import pytest
import os
import tempfile
import jwt
from apigateway.app import app, generate_token, decode_token
from datetime import datetime, timedelta

@pytest.fixture
def client():
    """Create a test client for the Flask app"""
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

@pytest.fixture
def auth_client(client):
    """Authenticated client with valid tokens"""
    # First register a user
    response = client.post('/api/auth/register', json={
        'email': 'test@example.com',
        'password': 'password123'
    })
    assert response.status_code == 201

    # Then login to get tokens
    response = client.post('/api/auth/login', json={
        'email': 'test@example.com',
        'password': 'password123'
    })
    assert response.status_code == 200

    # Return client with tokens
    tokens = response.get_json()
    return {
        'client': client,
        'access_token': tokens['access_token'],
        'refresh_token': tokens['refresh_token']
    }

@pytest.fixture
def valid_user_data():
    """Valid user registration data"""
    return {
        'email': 'test@example.com',
        'password': 'password123'
    }

@pytest.fixture
def invalid_user_data():
    """Invalid user data for testing error cases"""
    return [
        {'email': 'invalid-email'},  # missing password
        {'password': 'short'},  # missing email
        {'email': 'no-at-sign', 'password': 'password123'},  # invalid email
        {'email': 'test@example.com', 'password': 'short'},  # short password
        {'email': 'test @example.com', 'password': 'password123'},  # email with space
    ]

@pytest.fixture
def temp_log_file():
    """Temporary log file for testing logging"""
    fd, path = tempfile.mkstemp(suffix='.log')
    os.close(fd)
    yield path
    try:
        os.unlink(path)
    except:
        pass

@pytest.fixture
def generate_test_tokens():
    """Helper to generate test tokens"""
    def _generate_token(user_id=1, token_type='access', expires_in=None):
        now = datetime.utcnow()
        expires = now + timedelta(minutes=15) if expires_in is None else now + expires_in

        payload = {
            'sub': str(user_id),
            'iat': now,
            'exp': expires,
            'type': token_type
        }
        return jwt.encode(payload, app.config['SECRET_KEY'], algorithm=app.config['JWT_ALGORITHM'])
    return _generate_token