import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.main import app
from app.config import settings
from app.database import Base
from app.schemas import UserCreate, TaskCreate
from app.crud import get_user_by_email, get_user_by_username
from app.utils.security import get_password_hash

# Setup test database
SQLALCHEMY_DATABASE_URL = f"postgresql://{settings.DB_USER}:{settings.DB_PASSWORD}@localhost/{settings.DB_TEST_NAME}"
engine = create_engine(SQLALCHEMY_DATABASE_URL)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create tables
Base.metadata.create_all(bind=engine)

client = TestClient(app)

@pytest.fixture(scope="module")
def test_db():
    """Create test database"""
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def auth_headers():
    """Create authentication headers"""
    # Create test user
    db = TestingSessionLocal()
    try:
        user_data = UserCreate(username="tasktest", email="tasktest@example.com", password="taskpass123")
        from app.crud import create_user
        user = create_user(db, user_data)
    finally:
        db.close()

    # Login
    response = client.post(
        "/api/v1/auth/login",
        data={"username": user_data.username, "password": user_data.password}
    )
    assert response.status_code