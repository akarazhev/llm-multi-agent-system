# Factorial Calculator

A simple Python function to calculate the factorial of a non-negative integer.

## Usage

```python
from factorial import factorial

print(factorial(5))  # Output: 120