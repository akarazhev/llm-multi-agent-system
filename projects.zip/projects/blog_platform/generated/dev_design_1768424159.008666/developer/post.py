# File: backend/database/models.py
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database.base import Base

class Post(Base):
    __tablename__ = "posts"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    slug = Column(String(255), unique=True, index=True, nullable=False)
    content = Column(Text, nullable=False)
    excerpt = Column(Text)
    featured_image = Column(String(255))
    status = Column(String(20), default="draft")  # draft, published, archived
    published_at = Column(DateTime)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    author_id = Column(Integer, ForeignKey("users.id"))
    author = relationship("User", back_populates="posts")

    category_id = Column(Integer, ForeignKey("categories.id"))
    category = relationship("Category", back_populates="posts")

    tags = relationship("Tag", secondary="post_tags", back_populates="posts")
    revisions = relationship("PostRevision", back_populates="post")
    comments = relationship("Comment", back_populates="post")

class PostRevision(Base):
    __tablename__ = "post_revisions"

    id = Column(Integer, primary_key=True, index=True)
    post_id = Column(Integer, ForeignKey("posts.id"))
    version = Column(Integer, nullable=False)
    title = Column(String(255))
    content = Column(Text)
    excerpt = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    post = relationship("Post", back_populates="revisions")