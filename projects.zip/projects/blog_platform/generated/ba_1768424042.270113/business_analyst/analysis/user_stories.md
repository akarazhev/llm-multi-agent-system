# User Stories

## **1. Blog Post Management**
### **US-1: Create a Blog Post**
**Title**: As an author, I want to create a blog post so I can share my content.
**Acceptance Criteria**:
- Given I am logged in as an author, when I click "New Post", then a form opens with fields: title, slug, content (Markdown), excerpt, featured_image, status (draft).
- When I save, the post is auto-saved as a draft.

**Priority**: Must have
**Story Points**: 5
**Dependencies**: US-2 (Post Statuses)

### **US-2: Post Statuses**
**Title**: As an admin, I want to set post statuses so I can control publishing.
**Acceptance Criteria**:
- Status options: draft, published, archived.
- Only published posts appear on the homepage.

**Priority**: Must have
**Story Points**: 3

## **2. SEO Features**
### **US-3: SEO Metadata**
**Title**: As an editor, I want to add meta tags so posts rank better.
**Acceptance Criteria**:
- Meta title, description, and Open Graph tags auto-populate from post fields.
- Slug is SEO-friendly (lowercase, hyphens).

**Priority**: Should have
**Story Points**: 2

## **3. Comments System**
### **US-4: Moderate Comments**
**Title**: As an admin, I want to approve/reject comments so I can control spam.
**Acceptance Criteria**:
- Approved comments appear; rejected are hidden.
- Admin receives email notifications for new comments.

**Priority**: Should have
**Story Points**: 4