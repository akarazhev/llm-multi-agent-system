# File: backend/api/routers/posts.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from database.models import Post, User
from schemas.post import PostCreate, PostUpdate, PostResponse
from services.post_service import PostService
from services.auth_service import get_current_user

router = APIRouter(prefix="/posts", tags=["posts"])

@router.get("/", response_model=List[PostResponse])
def get_posts(
    db: Session = Depends(get_db),
    limit: int = 10,
    offset: int = 0,
    status: Optional[str] = None,
    author_id: Optional[int] = None,
    category_id: Optional[int] = None,
    tag_id: Optional[int] = None,
    search: Optional[str] = None
):
    return PostService.get_posts(
        db=db,
        limit=limit,
        offset=offset,
        status=status,
        author_id=author_id,
        category_id=category_id,
        tag_id=tag_id,
        search=search
    )

@router.post("/", response_model=PostResponse, status_code=status.HTTP_201_CREATED)
def create_post(
    post: PostCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return PostService.create_post(db=db, post=post, author_id=current_user.id)