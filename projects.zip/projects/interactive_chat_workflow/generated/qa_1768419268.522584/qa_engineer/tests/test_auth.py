import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.main import app
from app.config import settings
from app.database import Base
from app.schemas import UserCreate
from app.crud import get_user_by_email

# Setup test database
SQLALCHEMY_DATABASE_URL = f"postgresql://{settings.DB_USER}:{settings.DB_PASSWORD}@localhost/{settings.DB_TEST_NAME}"
engine = create_engine(SQLALCHEMY_DATABASE_URL)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create tables
Base.metadata.create_all(bind=engine)

client = TestClient(app)

@pytest.fixture(scope="module")
def test_db():
    """Create test database"""
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def test_user():
    """Create test user"""
    user_data = UserCreate(username="testuser", email="test@example.com", password="testpass123")
    db = TestingSessionLocal()
    user = get_user_by_email(db, user_data.email)
    if not user:
        user = get_user_by_email(db, user_data.email)
        if not user:
            from app.crud import create_user
            user = create_user(db, user_data)
    db.close()
    return user_data

def test_login_success(test_user):
    """Test successful user login"""
    response = client.post(
        "/api/v1/auth/login",
        data={"username": test_user.username, "password": test_user.password}
    )
    assert response.status_code == 200
    assert "access_token" in response.json()
    assert "refresh_token" in response.json()

def test_login_wrong_password():
    """Test login with wrong password"""
    response = client.post(
        "/api/v1/auth/login",
        data={"username": "testuser", "password": "wrongpass"}
    )
    assert response.status_code == 400
    assert "Incorrect password" in response.json()["detail"]

def test_login_nonexistent_user():
    """Test login with nonexistent user"""
    response = client.post(
        "/api/v1/auth/login",
        data={"username": "nonexistent", "password": "password"}
    )
    assert response.status_code == 400
    assert "User not found" in response.json()["detail"]

def test_refresh_token():
    """Test token refresh"""
    # First login to get tokens
    user_data = UserCreate(username="refreshuser", email="refresh@example.com", password="refreshpass")
    db = TestingSessionLocal()
    try:
        from app.crud import create_user
        user = create_user(db, user_data)
    finally:
        db.close()

    login_response = client.post(
        "/api/v1/auth/login",
        data={"username": user_data.username, "password": user_data.password}
    )
    refresh_token = login_response.json()["refresh_token"]

    # Test refresh
    response = client.post(
        "/api/v1/auth/refresh",
        json={"refresh_token": refresh_token}
    )
    assert response.status_code == 200
    assert "access_token" in response.json()

def test_invalid_refresh_token():
    """Test invalid refresh token"""
    response = client.post(
        "/api/v1/auth/refresh",
        json={"refresh_token": "invalid_token"}
    )
    assert response.status_code == 400
    assert "Invalid refresh token" in response.json()["detail"]