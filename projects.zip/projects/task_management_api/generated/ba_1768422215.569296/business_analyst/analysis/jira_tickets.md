# Jira Ticket Structure

## Epic: Task Management API
- **Parent**: TASK-API-1

## User Stories (Sub-tasks)
1. **TASK-API-1-1**: User Registration
2. **TASK-API-1-2**: User Login (JWT)
3. **TASK-API-1-3**: Task CRUD
4. **TASK-API-1-4**: WebSocket Notifications

## Labels
- `backend`, `fastapi`, `postgres`