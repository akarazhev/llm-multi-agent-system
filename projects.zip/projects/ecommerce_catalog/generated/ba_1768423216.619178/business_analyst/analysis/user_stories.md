# User Stories for E-Commerce Product Catalog

## Epic: Product Management
### US-PM-01: Admin Product CRUD
**Title**: Create, read, update, and delete products.
**As a** admin,
**I want** to manage products (CRUD operations),
**So that** the catalog is always up-to-date.

**Acceptance Criteria**:
- Given I am logged in as an admin,
- When I navigate to the product management page,
- Then I can add, edit, or delete products with all required fields.

**Priority**: Must have
**Story Points**: 8
**Dependencies**: Auth system, PostgreSQL schema.

### US-PM-02: Product Variants
**Title**: Support product variants (size, color).
**As a** admin,
**I want** to define variants for products,
**So that** customers can choose options.

**Acceptance Criteria**:
- Given a product with variants (e.g., "T-Shirt" with sizes S/M/L),
- When a user selects a variant,
- Then the price/stock reflects the chosen option.

**Priority**: Should have
**Story Points**: 5
**Dependencies**: Product schema, inventory tracking.

## Epic: Shopping Cart
### US-CART-01: Add Items to Cart
**Title**: Add products to the shopping cart.
**As a** user,
**I want** to add items to my cart,
**So that** I can purchase them later.

**Acceptance Criteria**:
- Given a product page,
- When I click "Add to Cart",
- Then the item is added with quantity = 1.

**Priority**: Must have
**Story Points**: 3
**Dependencies**: Cart API, session management.

## Epic: Payment Integration
### US-PAY-01: Stripe Checkout
**Title**: Process payments via Stripe.
**As a** user,
**I want** to pay with my credit card,
**So that** my order is confirmed.

**Acceptance Criteria**:
- Given a valid cart,
- When I enter payment details,
- Then Stripe processes the payment and returns a confirmation.

**Priority**: Must have
**Story Points**: 13
**Dependencies**: Stripe API, order management.