# Task Management REST API Documentation

A comprehensive task management system with JWT authentication, real-time updates, and RESTful API endpoints.

## Table of Contents
1. [Overview](#overview)
2. [Features](#features)
3. [Quick Start](#quick-start)
4. [API Documentation](#api-documentation)
5. [WebSocket Documentation](#websocket-documentation)
6. [Setup and Configuration](#setup-and-configuration)
7. [Testing](#testing)
8. [Deployment](#deployment)
9. [Troubleshooting](#troubleshooting)
10. [References](#references)

## Overview

This API provides a complete solution for task management with user authentication, task lifecycle management, and real-time notifications. Built with FastAPI, PostgreSQL, and JWT authentication, it's designed for scalability and ease of integration.

## Features

- **User Authentication**: JWT-based secure authentication with bcrypt password hashing
- **Task Management**: Full CRUD operations for tasks with status and priority tracking
- **Real-time Updates**: WebSocket support for instant notifications
- **Modern Stack**: Python 3.11+, FastAPI, SQLAlchemy, PostgreSQL
- **Testing**: Comprehensive pytest coverage
- **Deployment**: Docker and Docker Compose ready

## Quick Start

### Prerequisites
- Python 3.11+
- PostgreSQL
- Docker (optional)

### Installation

```bash
git clone https://github.com/your-repo/task-management-api.git
cd task-management-api
pip install -r requirements.txt
```

### Running the API

```bash
# Using Python
uvicorn app.main:app --reload

# Using Docker
docker-compose up --build
```

### Basic Usage

```bash
# Register a new user
curl -X POST "http://localhost:8000/auth/register" \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"securepassword"}'

# Login to get JWT token
curl -X POST "http://localhost:8000/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"securepassword"}'

# Create a task (with token from login)
curl -X POST "http://localhost:8000/tasks/" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title":"Test Task","description":"Test description","priority":"HIGH"}'
```

## API Documentation

### Authentication Endpoints

#### Register a new user
```
POST /auth/register
```
**Request Body:**
```json
{
  "username": "string",
  "email": "string",
  "password": "string"
}
```

**Response:**
```json
{
  "id": "integer",
  "username": "string",
  "email": "string"
}
```

#### Login and get JWT token
```
POST /auth/login
```
**Request Body:**
```json
{
  "username": "string",
  "password": "string"
}
```

**Response:**
```json
{
  "access_token": "string",
  "token_type": "bearer"
}
```

### Task Management Endpoints

#### Create a new task
```
POST /tasks/
```
**Headers:**
- Authorization: Bearer {JWT_TOKEN}

**Request Body:**
```json
{
  "title": "string",
  "description": "string (optional)",
  "priority": "LOW|MEDIUM|HIGH|URGENT",
  "due_date": "YYYY-MM-DD (optional)",
  "assigned_to": "integer (user_id, optional)"
}
```

**Response:**
```json
{
  "id": "integer",
  "title": "string",
  "description": "string",
  "status": "TODO",
  "priority": "string",
  "due_date": "string",
  "assigned_to": "integer",
  "created_at": "datetime",
  "updated_at": "datetime"
}
```

#### Get all tasks
```
GET /tasks/
```
**Query Parameters:**
- status: filter by status (TODO, IN_PROGRESS, etc.)
- priority: filter by priority
- assigned_to: filter by user ID
- limit: number of items per page
- offset: pagination offset

#### Get a specific task
```
GET /tasks/{task_id}
```

#### Update a task
```
PUT /tasks/{task_id}
```
**Request Body:** Same as create, with fields to update

#### Delete a task
```
DELETE /tasks/{task_id}
```

## WebSocket Documentation

The API provides real-time updates through WebSocket connections.

### Connecting to WebSocket
```python
from websockets import connect
import asyncio

async def listen_for_updates():
    async with connect("ws://localhost:8000/ws/tasks") as websocket:
        while True:
            message = await websocket.recv()
            print(message)
```

### WebSocket Events

**Task Created:**
```json
{
  "type": "task_created",
  "data": {
    "task_id": 123,
    "title": "New Task",
    "status": "TODO",
    "assigned_to": 456
  }
}
```

**Task Updated:**
```json
{
  "type": "task_updated",
  "data": {
    "task_id": 123,
    "changes": {
      "status": "IN_PROGRESS",
      "priority": "HIGH"
    }
  }
}
```

**Task Assigned:**
```json
{
  "type": "task_assigned",
  "data": {
    "task_id": 123,
    "user_id": 456,
    "user_email": "user@example.com"
  }
}
```

## Setup and Configuration

### Environment Variables

Create a `.env` file with the following variables:

```bash
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=taskdb
DB_USER=postgres
DB_PASSWORD=yourpassword

# JWT
SECRET_KEY=your-secret-key-here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Application
APP_HOST=0.0.0.0
APP_PORT=8000
```

### Database Setup

1. Install PostgreSQL
2. Create a database:
```sql
CREATE DATABASE taskdb;
```
3. Run migrations (if using Alembic):
```bash
alembic upgrade head
```

### Configuration Files

**File: app/config.py**
```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    db_host: str
    db_port: int
    db_name: str
    db_user: str
    db_password: str
    secret_key: str
    algorithm: str
    access_token_expire_minutes: int
    app_host: str
    app_port: int

    class Config:
        env_file = ".env"

settings = Settings()
```

## Testing

### Running Tests

```bash
# Run all tests
pytest tests/

# Run with coverage
pytest tests/ --cov=app --cov-report=html
```

### Test Structure

**File: tests/conftest.py**