# E-Commerce Platform - Product Service Documentation

## Overview and Introduction

The Product Service is a microservice within the e-commerce platform responsible for managing product catalog operations. This FastAPI-based service provides endpoints for product creation, retrieval, updating, and deletion.

### Key Features
- RESTful API for product management
- CRUD operations for product catalog
- Scalable architecture supporting 10,000+ DAU
- Kubernetes-ready deployment
- Comprehensive test coverage

### Architecture
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Client     │───▶│  Product     │───▶│  Cart       │───▶│  Payment     │
│             │◀───│  Service     │◀───│  Service     │◀───│  Service     │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
       ▲                   ▲                     ▲
       │                   │                     │
┌──────┴──────┐     ┌──────┴──────┐     ┌───────┴───────┐
│   Database  │     │   Cache     │     │   Search      │
└─────────────┘     └─────────────┘     └───────────────┘
```

## Detailed Explanations with Examples

### Product Model

```python
# Data models used in the service
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class ProductBase(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    stock: int
    category: str

class Product(ProductBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True
```

### API Endpoints

#### Create Product
```http
POST /products/
Content-Type: application/json

{
    "name": "Wireless Headphones",
    "description": "Noise-cancelling wireless headphones",
    "price": 199.99,
    "stock": 100,
    "category": "electronics"
}
```

#### Get Product by ID
```http
GET /products/1
```

#### Update Product
```http
PUT /products/1
Content-Type: application/json

{
    "price": 179.99,
    "stock": 75
}
```

#### Delete Product
```http
DELETE /products/1
```

#### Search Products
```http
GET /products/?category=electronics&min_price=100&max_price=200&limit=10&offset=0
```

## Configuration and Setup Instructions

### Prerequisites
- Python 3.8+
- FastAPI
- Uvicorn
- SQLAlchemy
- Alembic
- Kubernetes CLI (kubectl)
- AWS CLI
- Docker

### Local Development Setup

1. Clone the repository:
```bash
git clone https://github.com/yourorg/product-service.git
cd product-service
```

2. Create virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your configuration
```

5. Run migrations:
```bash
alembic upgrade head
```

6. Start the service:
```bash
uvicorn app.main:app --reload
```

### Kubernetes Deployment

```yaml
# Example deployment configuration
apiVersion: apps/v1
kind: Deployment
metadata:
  name: product-service
spec:
  replicas: 3
  selector:
    matchLabels:
      app: product-service
  template:
    metadata:
      labels:
        app: product-service
    spec:
      containers:
      - name: product-service
        image: your-ecr-repo/product-service:latest
        ports:
        - containerPort: 8000
        envFrom:
        - configMapRef:
            name: product-service-config
        - secretRef:
            name: product-service-secrets
```

## Code Snippets and Usage Examples

### Python Client Example

```python
import requests
import json

BASE_URL = "http://localhost:8000"

# Create a new product
def create_product(product_data):
    response = requests.post(f"{BASE_URL}/products/", json=product_data)
    return response.json()

# Get product details
def get_product(product_id):
    response = requests.get(f"{BASE_URL}/products/{product_id}")
    return response.json()

# Example usage
product = {
    "name": "Smart Watch",
    "description": "Fitness tracking watch with heart rate monitor",
    "price": 249.99,
    "stock": 50,
    "category": "wearables"
}

new_product = create_product(product)
print(f"Created product with ID: {new_product['id']}")

product_details = get_product(new_product['id'])
print(f"Product details: {product_details}")
```

### cURL Examples

```bash
# Create product
curl -X POST "http://localhost:8000/products/" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Bluetooth Speaker",
    "description": "Portable waterproof speaker",
    "price": 89.99,
    "stock": 150,
    "category": "audio"
  }'

# Get all products
curl "http://localhost:8000/products/"

# Search products
curl "http://localhost:8000/products/?category=audio&min_price=50&max_price=100"
```

## Troubleshooting Section

### Common Issues and Solutions

1. **Connection Refused Error**
   - Ensure the service is running: `uvicorn app.main:app --reload`
   - Check port availability: `lsof -i :8000`
   - Verify environment variables are set correctly

2. **Database Connection Problems**
   - Check database server is running
   - Verify connection string in `.env` file
   - Test connection manually: `psql -h localhost -U username -d dbname`

3. **500 Internal Server Error**
   - Check application logs: `kubectl logs <pod-name>`
   - Verify all required fields are provided in requests
   - Ensure product ID exists when updating/deleting

4. **422 Validation Error**
   - Review request payload against the Product model
   - Check required fields are included
   - Verify data types match (e.g., price must be float)

5. **404 Not Found**
   - Confirm the product ID exists
   - Verify the endpoint URL is correct
   - Check if the product has been soft-deleted

### Debugging Tips

- Enable debug logging: `LOG_LEVEL=debug` in `.env`
- Check Kubernetes logs: `kubectl logs -f <pod-name>`
- Inspect database: `kubectl exec -it <db-pod> -- psql -U username -d dbname`
- Test endpoints with Swagger UI: `/docs`

## References and Related Resources

### API Documentation
- Swagger UI: `/docs` (when service is running)
- OpenAPI Spec: `/openapi.json`

### Related Services
- [Cart Service Documentation](https://github.com/yourorg/cart-service)
- [Payment Service Documentation](https://github.com/yourorg/payment-service)
- [User Service Documentation](https://github.com/yourorg/user-service)

### Development Tools
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [SQLAlchemy Documentation](https://www.sqlalchemy.org/)
- [Alembic Migration Tool](https://alembic.sqlalchemy.org/)
- [Kubernetes Documentation](https://kubernetes.io/docs/home/)

### Testing
- [Test Coverage Report](https://yourorg.github.io/product-service/coverage/)
- [Test Results](https://yourorg.github.io/product-service/tests/)

### Architecture Diagrams
- [System Architecture](https://github.com/yourorg/ecommerce-platform/blob/main/docs/architecture.md)
- [Data Flow](https://github.com/yourorg/ecommerce-platform/blob/main/docs/data-flow.md)

### Support
- Issue Tracker: [GitHub Issues](https://github.com/yourorg/product-service/issues)
- Slack Channel: `#team-product-service`
- Mailing List: `product-service@yourorg.com`