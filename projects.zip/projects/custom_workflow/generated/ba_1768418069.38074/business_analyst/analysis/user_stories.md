# User Stories for E-Commerce Platform

## Product Service

### US1: Product Catalog
**Title**: View product catalog
- **As a** customer,
- **I want** to browse products by category,
- **So that** I can find items I’m interested in.

**Acceptance Criteria**:
- Given a user visits the catalog page,
- When they select a category,
- Then products in that category are displayed with images, names, and prices.

**Priority**: Must have
**Story Points**: 5
**Dependencies**: None

---

### US2: Product Search
**Title**: Search for products
- **As a** customer,
- **I want** to search for products by keyword,
- **So that** I can quickly find specific items.

**Acceptance Criteria**:
- Given a user enters a keyword in the search bar,
- When they submit the search,
- Then matching products are displayed with relevant results.

**Priority**: Should have
**Story Points**: 3
**Dependencies**: US1

---

## Cart Service

### US3: Add to Cart
**Title**: Add items to shopping cart
- **As a** customer,
- **I want** to add products to my cart,
- **So that** I can purchase them later.

**Acceptance Criteria**:
- Given a user is on a product page,
- When they click "Add to Cart",
- Then the item is added to their cart with quantity 1.

**Priority**: Must have
**Story Points**: 5
**Dependencies**: US1

---

### US4: View Cart
**Title**: View shopping cart
- **As a** customer,
- **I want** to see all items in my cart,
- **So that** I can review before checkout.

**Acceptance Criteria**:
- Given a user navigates to the cart page,
- When the page loads,
- Then all items in the cart are displayed with prices and quantities.

**Priority**: Must have
**Story Points**: 3
**Dependencies**: US3

---

## Payment Service

### US5: Checkout with Payment
**Title**: Complete purchase with payment
- **As a** customer,
- **I want** to pay for items in my cart,
- **So that** I can receive my order.

**Acceptance Criteria**:
- Given a user proceeds to checkout,
- When they enter payment details and submit,
- Then payment is processed, and an order confirmation is sent.

**Priority**: Must have
**Story Points**: 8
**Dependencies**: US4

---

## User Service

### US6: User Authentication
**Title**: Log in to account
- **As a** customer,
- **I want** to log in with my credentials,
- **So that** I can access my profile and order history.

**Acceptance Criteria**:
- Given a user enters valid email and password,
- When they click "Login",
- Then they are redirected to their dashboard.

**Priority**: Must have
**Story Points**: 5
**Dependencies**: None

---

### US7: Order History
**Title**: View past orders
- **As a** customer,
- **I want** to see my order history,
- **So that** I can track previous purchases.

**Acceptance Criteria**:
- Given a logged-in user visits the order history page,
- When the page loads,
- Then all past orders are displayed with dates and statuses.

**Priority**: Should have
**Story Points**: 5
**Dependencies**: US6, US5