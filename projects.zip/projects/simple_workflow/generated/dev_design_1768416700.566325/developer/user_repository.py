# File: user_service/user_repository.py
from typing import Optional
from datetime import datetime

class UserRepository:
    def __init__(self, db_connection):
        self.db = db_connection

    def create_user(self, email: str, password_hash: str) -> int:
        """Create new user in database"""
        cursor = self.db.cursor()
        cursor.execute(
            "INSERT INTO users (email, password_hash, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (email.lower(), password_hash, datetime.utcnow(), datetime.utcnow())
        )
        self.db.commit()
        return cursor.lastrowid

    def get_user_by_email(self, email: str) -> Optional[dict]:
        """Get user by email"""
        cursor = self.db.cursor()
        cursor.execute("SELECT id, email, password_hash, last_login FROM users WHERE email = ?", (email.lower(),))
        return cursor.fetchone()

    def update_last_login(self, user_id: int) -> None:
        """Update user's last login time"""
        cursor = self.db.cursor()
        cursor.execute(
            "UPDATE users SET last_login = ?, updated_at = ? WHERE id = ?",
            (datetime.utcnow(), datetime.utcnow(), user_id)
        )
        self.db.commit()