# File: backend/services/post_service.py
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from database.models import Post, PostRevision
from schemas.post import PostCreate, PostUpdate, PostResponse
from utils.slug_generator import generate_slug
from utils.markdown_converter import convert_markdown_to_html

class PostService:
    @staticmethod
    def create_post(db: Session, post: PostCreate, author_id: int) -> Post:
        slug = generate_slug(post.title)

        # Create initial revision
        revision = PostRevision(
            title=post.title,
            content=post.content,
            excerpt=post.excerpt or post.content[:200],
            version=1
        )

        db_post = Post(
            title=post.title,
            slug=slug,
            content=convert_markdown_to_html(post.content),
            excerpt=post.excerpt,
            featured_image=post.featured_image,
            status=post.status,
            author_id=author_id,
            revisions=[revision]
        )

        if post.category_id:
            db_post.category_id = post.category_id

        if post.tags:
            db_post.tags = post.tags

        db.add(db_post)
        db.commit()
        db.refresh(db_post)

        return db_post