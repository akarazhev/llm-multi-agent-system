from flask import Flask, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import datetime
import os
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import logging
from logging.handlers import RotatingFileHandler
import bcrypt
from typing import Optional, Dict, Any

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.getenv('JWT_SECRET', 'default-secret-key-for-dev')
app.config['JWT_ALGORITHM'] = 'HS256'
app.config['JWT_EXPIRATION_ACCESS'] = 15  # minutes
app.config['JWT_EXPIRATION_REFRESH'] = 7  # days

# Rate limiting
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Logging configuration
handler = RotatingFileHandler('auth.log', maxBytes=10000, backupCount=3)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
app.logger.addHandler(handler)

class AuthError(Exception):
    def __init__(self, error: str, status_code: int):
        super().__init__()
        self.error = error
        self.status_code = status_code

@app.errorhandler(AuthError)
def handle_auth_error(error: AuthError):
    response = jsonify({
        "error": error.error,
        "status_code": error.status_code
    })
    return response, error.status_code

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    app.logger.error(f"Server error: {str(error)}")
    return jsonify({"error": "Internal server error"}), 500

def generate_token(user_id: int, token_type: str = 'access') -> str:
    """Generate JWT token with appropriate expiration"""
    now = datetime.datetime.utcnow()
    if token_type == 'access':
        expires = now + datetime.timedelta(minutes=app.config['JWT_EXPIRATION_ACCESS'])
    elif token_type == 'refresh':
        expires = now + datetime.timedelta(days=app.config['JWT_EXPIRATION_REFRESH'])
    else:
        raise AuthError("Invalid token type", 400)

    payload = {
        'sub': str(user_id),
        'iat': now,
        'exp': expires,
        'type': token_type
    }
    return jwt.encode(payload, app.config['SECRET_KEY'], algorithm=app.config['JWT_ALGORITHM'])

def decode_token(token: str) -> Dict[str, Any]:
    """Decode and verify JWT token"""
    try:
        payload = jwt.decode(
            token,
            app.config['SECRET_KEY'],
            algorithms=[app.config['JWT_ALGORITHM']]
        )
        return payload
    except jwt.ExpiredSignatureError:
        raise AuthError("Token has expired", 401)
    except jwt.InvalidTokenError:
        raise AuthError("Invalid token", 401)

@app.route('/api/auth/register', methods=['POST'])
@limiter.limit("5 per minute")
def register():
    """Register a new user"""
    try:
        data = request.get_json()
        if not data or 'email' not in data or 'password' not in data:
            raise AuthError("Email and password are required", 400)

        email = data['email'].strip().lower()
        password = data['password'].strip()

        # Input validation
        if not email or '@' not in email or ' ' in email:
            raise AuthError("Invalid email format", 400)
        if len(password) < 8:
            raise AuthError("Password must be at least 8 characters", 400)

        # In a real implementation, this would call the UserService
        # For this example, we'll simulate the database interaction
        # Hash the password
        password_hash = bcrypt.hashpw(
            password.encode('utf-8'),
            bcrypt.gensalt(12)
        ).decode('utf-8')

        # Simulate user creation
        user_id = 1  # This would be the actual user ID from the database

        app.logger.info(f"User registered with email: {email}")

        return jsonify({
            "message": "User registered successfully",
            "user_id": user_id
        }), 201

    except AuthError as e:
        raise e
    except Exception as e:
        app.logger.error(f"Registration error: {str(e)}")
        raise AuthError("Registration failed", 500)

@app.route('/api/auth/login', methods=['POST'])
@limiter.limit("10 per minute")
def login():
    """Authenticate user and return JWT tokens"""
    try:
        data = request.get_json()
        if not data or 'email' not in data or 'password' not in data:
            raise AuthError("Email and password are required", 400)

        email = data['email'].strip().lower()
        password = data['password'].strip()

        # In a real implementation, this would call the UserService to get user
        # For this example, we'll simulate the database interaction
        # Simulated user data
        user = {
            'id': 1,
            'email': email,
            'password_hash': bcrypt.hashpw(
                'password123'.encode('utf-8'),
                bcrypt.gensalt(12)
            ).decode('utf-8')
        }

        # Verify password
        if not bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8')):
            app.logger.warning(f"Failed login attempt for email: {email}")
            raise AuthError("Invalid email or password", 401)

        # Generate tokens
        access_token = generate_token(user['id'], 'access')
        refresh_token = generate_token(user['id'], 'refresh')

        app.logger.info(f"User logged in with email: {email}")

        return jsonify({