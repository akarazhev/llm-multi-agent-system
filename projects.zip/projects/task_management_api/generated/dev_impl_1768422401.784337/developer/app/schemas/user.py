"""User Pydantic schemas."""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional

class UserBase(BaseModel):
    """Base user model."""
    email: EmailStr = Field(..., example="user@example.com")
    username: str = Field(..., example="johndoe", min_length=3, max_length=50)

class UserCreate(UserBase):
    """User creation model."""
    password: str = Field(..., example="securepassword123", min_length=8)

class User(UserBase):
    """User response model."""
    id: int = Field(..., example=1)

    class Config:
        """Pydantic configuration."""
        from_attributes = True

class UserInDB(User):
    """User in database model."""
    hashed_password: str = Field(..., example="hashed_password_here")