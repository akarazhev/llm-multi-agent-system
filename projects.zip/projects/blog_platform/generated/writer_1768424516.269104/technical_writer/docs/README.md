# Blog Platform with CMS Documentation

A comprehensive content management system for blogging with rich features for content creation, organization, and user management.

## Table of Contents
- [Overview](#overview)
- [Features](#features)
- [Getting Started](#getting-started)
  - [Prerequisites](#prerequisites)
  - [Installation](#installation)
  - [Configuration](#configuration)
- [Core Components](#core-components)
  - [Blog Post Management](#blog-post-management)
  - [Content Organization](#content-organization)
  - [User Management](#user-management)
  - [Comments System](#comments-system)
  - [Media Management](#media-management)
  - [Search and Discovery](#search-and-discovery)
- [API Reference](#api-reference)
- [Development](#development)
  - [Environment Setup](#environment-setup)
  - [Running Tests](#running-tests)
  - [Database Migrations](#database-migrations)
- [Deployment](#deployment)
- [Troubleshooting](#troubleshooting)
- [Contributing](#contributing)
- [License](#license)

## Overview

This Blog Platform with CMS provides a complete solution for managing blog content with advanced features for content creators, editors, and administrators. Built with modern web technologies, it offers a flexible architecture that can be customized for various blogging needs.

## Features

### Blog Post Management
- Create, edit, and delete blog posts
- Rich text editor with Markdown support
- Post scheduling and auto-publishing
- Version history and revisions
- Multiple post statuses (draft, published, archived)

### Content Organization
- Hierarchical categories
- Flat tagging system
- Featured posts highlighting
- Related posts suggestions
- Custom post types and taxonomies

### User Management
- Role-based access control (admin, editor, author, subscriber)
- User profiles with avatars and bios
- Author pages showing all posts
- Custom registration and login flows

### Comments System
- Nested comment threads
- Moderation queue
- Email notifications
- Comment voting and reactions

### Media Management
- Image and file uploads
- Media library with organization
- Image optimization
- Custom media handlers

### Search and Discovery
- Full-text search
- Advanced filtering
- Related content suggestions
- SEO optimization features

## Getting Started

### Prerequisites
- Python 3.8+
- Node.js 14+
- PostgreSQL 12+
- Redis (for caching)
- Docker (optional, for containerized deployment)

### Installation

#### Backend Setup
```bash
# Clone the repository
git clone https://github.com/your-repo/blog-platform-cms.git
cd blog-platform-cms

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set up environment variables
cp .env.example .env
nano .env  # Edit as needed
```

#### Frontend Setup
```bash
# Install frontend dependencies
cd frontend
npm install

# Build the frontend
npm run build
```

#### Database Setup
```bash
# Create database
createdb blog_platform

# Run migrations
alembic upgrade head
```

### Configuration

Edit the `.env` file to configure your application:

```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/blog_platform

# Application
SECRET_KEY=your-secret-key
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1

# Email
MAIL_SERVER=smtp.example.com
MAIL_PORT=587
MAIL_USERNAME=user@example.com
MAIL_PASSWORD=password
MAIL_USE_TLS=True

# Media
MEDIA_ROOT=/path/to/media
MEDIA_URL=/media/

# Caching
CACHE_URL=redis://localhost:6379/0
```

## Core Components

### Blog Post Management

#### Post Model
```python
from datetime import datetime
from enum import Enum

class PostStatus(Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    ARCHIVED = "archived"

class Post(Base):
    __tablename__ = "posts"

    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    slug = Column(String(255), unique=True, nullable=False)
    content = Column(Text, nullable=False)
    excerpt = Column(Text)
    featured_image = Column(String(255))
    status = Column(Enum(PostStatus), default=PostStatus.DRAFT)
    published_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    author_id = Column(Integer, ForeignKey("users.id"))
    category_id = Column(Integer, ForeignKey("categories.id"))

    # Relationships
    author = relationship("User", back_populates="posts")
    category = relationship("Category", back_populates="posts")
    tags = relationship("Tag", secondary="post_tags", back_populates="posts")
    revisions = relationship("PostRevision", back_populates="post")
    comments = relationship("Comment", back_populates="post")
```

#### Creating a Post (API Example)
```bash
curl -X POST "http://localhost:8000/api/posts/" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "My First Blog Post",
    "slug": "my-first-blog-post",
    "content": "# Hello World\n\nThis is my first blog post!",
    "excerpt": "Introduction to my new blog",
    "featured_image": "/uploads/featured.jpg",
    "status": "published",
    "category_id": 1,
    "tag_ids": [1, 2, 3]
  }'
```

### Content Organization

#### Category and Tag System
```python
class Category(Base):
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    slug = Column(String(100), unique=True, nullable=False)
    parent_id = Column(Integer, ForeignKey("categories.id"))
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    parent = relationship("Category", remote_side=[id])
    children = relationship("Category")
    posts = relationship("Post", back_populates="category")

class Tag(Base):
    __tablename__ = "tags"

    id = Column(Integer, primary_key=True)
    name = Column(String(50), unique=True, nullable=False)
    slug = Column(String(50), unique=True, nullable=False)
    description = Column(Text)

    # Relationships
    posts = relationship("Post", secondary="post_tags", back_populates="tags")
```

### User Management

#### User Roles and Permissions
```python
class UserRole(Enum):
    ADMIN = "admin"
    EDITOR = "editor"
    AUTHOR = "author"
    SUBSCRIBER = "subscriber"

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(128))
    role = Column(Enum(UserRole), default=UserRole.SUBSCRIBER)
    bio = Column(Text)
    avatar = Column(String(255))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime)

    # Relationships
    posts = relationship("Post", back_populates="author")
    comments = relationship("Comment", back_populates="author")
```

#### Authentication Endpoints
```bash
# Register a new user
curl -X POST "http://localhost:8000/api/auth/register/" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "johndoe",
    "email": "john@example.com",
    "password": "securepassword123"
  }'

# Login and get access token
curl -X POST "http://localhost:8000/api/auth/login/" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "johndoe",
    "password": "securepassword123"
  }'