# User Stories

## Authentication
1. **As a** new user, **I want** to register with email and password **so that** I can access the system.
   - Acceptance: POST `/auth/register` returns 201 with JWT.
   - Priority: Must Have
   - Story Points: 3

2. **As a** registered user, **I want** to log in with email/password **so that** I get a JWT token.
   - Acceptance: POST `/auth/login` returns 200 with JWT.
   - Priority: Must Have
   - Story Points: 2

## Task Management
3. **As a** user, **I want** to create a task with title, description, and due date **so that** I can track work.
   - Acceptance: POST `/tasks` returns 201.
   - Priority: Must Have
   - Story Points: 5

4. **As a** user, **I want** to list tasks filtered by status/priority **so that** I focus on relevant work.
   - Acceptance: GET `/tasks?status=TODO` returns filtered results.
   - Priority: Should Have
   - Story Points: 3

5. **As a** user, **I want** real-time notifications when a task is assigned to me **so that** I act promptly.
   - Acceptance: WebSocket emits `task_assigned` event.
   - Priority: Should Have
   - Story Points: 8

## Business Value Assessment
- **High Value**: Authentication (FR1-FR2) and CRUD (FR3) drive core functionality.
- **Medium Value**: Filtering (FR4) and WebSockets (FR5) enhance usability.